/*
.. Colton Kennedy - 251 089 374 - 10/28/2022
.. Header that contains a Polygon Counter.
*/

#ifndef COMMON_H
#define COMMON_H

namespace Counter{
    class Polygons{
        public:
            static int count;
    };
}

#endif